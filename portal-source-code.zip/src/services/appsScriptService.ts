import { Submission, LecturerSettings, Assignment } from '../types';

export interface DispatchResult {
  success: boolean;
  driveFileUrl?: string;
  driveFileId?: string;
  emailSent?: boolean;
  message: string;
}

export const generateAppsScriptCode = (settings: LecturerSettings): string => {
  return `/**
 * =======================================================================
 * GOOGLE APPS SCRIPT - WEBHOOK PORTAL TUGAS DOSEN REZA LUBIS
 * Target Akun: ${settings.emailDosen}
 * Target Folder Default: ${settings.googleDriveDefaultFolderId}
 * =======================================================================
 * CARA PEMASANGAN (HANYA 3 MENIT):
 * 1. Buka https://script.google.com/home dengan akun ${settings.emailDosen}
 * 2. Klik "New Project" / "Proyek Baru"
 * 3. Hapus semua kode bawaan, lalu COPY-PASTE SELURUH KODE DI BAWAH INI
 * 4. Klik tombol "Deploy" (di kanan atas) -> "New deployment"
 * 5. Pilih tipe: "Web app"
 * 6. Isi:
 *    - Description: "Webhook Tugas Mahasiswa"
 *    - Execute as: "Me (${settings.emailDosen})"
 *    - Who has access: "Anyone" (Siapa saja, agar mahasiswa bisa submit file tanpa login)
 * 7. Klik "Deploy" -> Berikan Izin Akses Akun Google Anda
 * 8. Salin URL Web App yang berakhiran "/exec" dan tempelkan ke menu Pengaturan Admin di portal ini!
 * =======================================================================
 */

const DEFAULT_DRIVE_FOLDER_ID = "${settings.googleDriveDefaultFolderId}";
const DOSEN_EMAIL = "${settings.emailDosen}";
const DOSEN_NAMA = "${settings.namaDosen}, ${settings.gelar}";
const KAMPUS = "${settings.kampus}";

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    
    // 1. Tentukan Folder Target di Google Drive
    const targetFolderId = data.driveFolderId || DEFAULT_DRIVE_FOLDER_ID;
    let targetFolder;
    try {
      targetFolder = DriveApp.getFolderById(targetFolderId);
    } catch (err) {
      targetFolder = DriveApp.getRootFolder();
    }
    
    // 2. Simpan File ke Google Drive jika ada file base64
    let fileUrl = "";
    let fileId = "";
    if (data.file && data.file.base64Data) {
      const decodedData = Utilities.base64Decode(data.file.base64Data);
      const blob = Utilities.newBlob(decodedData, data.file.type, data.file.name);
      const uploadedFile = targetFolder.createFile(blob);
      
      // Berikan akses agar Dosen & Mahasiswa dapat melihat file
      uploadedFile.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      fileUrl = uploadedFile.getUrl();
      fileId = uploadedFile.getId();
    }
    
    // 3. Kirim Email Konfirmasi Otomatis via Gmail Dosen
    if (data.emailPengirim) {
      const subject = "[TANDA TERIMA TUGAS] " + data.judulKarya + " - " + data.namaPengirim;
      const htmlBody = \`
        <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: auto; border: 1px solid #e2e8f0; border-radius: 8px; padding: 24px;">
          <h2 style="color: #1e3a8a; border-bottom: 2px solid #3b82f6; padding-bottom: 8px;">Bukti Pengumpulan Tugas Mahasiswa</h2>
          <p>Yth. <b>\${data.namaPengirim}</b> (NIM: \${data.nimPengirim}),</p>
          <p>Tugas Anda telah berhasil diterima dan tercatat di sistem pengumpulan tugas <b>\${KAMPUS}</b>.</p>
          
          <table style="width: 100%; border-collapse: collapse; margin: 16px 0; background-color: #f8fafc; border-radius: 6px;">
            <tr><td style="padding: 8px 12px; font-weight: bold; width: 35%;">ID Registrasi</td><td style="padding: 8px 12px;">\${data.id}</td></tr>
            <tr><td style="padding: 8px 12px; font-weight: bold;">Mata Kuliah</td><td style="padding: 8px 12px;">\${data.namaMk || '-'}</td></tr>
            <tr><td style="padding: 8px 12px; font-weight: bold;">Judul Tugas</td><td style="padding: 8px 12px;">\${data.judulKarya}</td></tr>
            <tr><td style="padding: 8px 12px; font-weight: bold;">Waktu Pengiriman</td><td style="padding: 8px 12px;">\${data.waktuKirimFormatted || new Date().toLocaleString('id-ID')} WIB</td></tr>
            <tr><td style="padding: 8px 12px; font-weight: bold;">Status</td><td style="padding: 8px 12px; color: #16a34a; font-weight: bold;">Tercatat (Menunggu Review Dosen)</td></tr>
          </table>

          <p>Anda dapat melakukan pengecekan status validasi dan nilai secara mandiri menggunakan NIM Anda pada portal penugasan mahasiswa.</p>
          
          <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid #e2e8f0; font-size: 13px; color: #64748b;">
            <p>Salam hangat,<br><b>\${DOSEN_NAMA}</b><br>Email: \${DOSEN_EMAIL}</p>
          </div>
        </div>
      \`;

      GmailApp.sendEmail(data.emailPengirim, subject, "Tugas berhasil dikumpulkan", {
        htmlBody: htmlBody,
        replyTo: DOSEN_EMAIL,
        name: DOSEN_NAMA
      });
    }

    return ContentService.createTextOutput(JSON.stringify({
      status: "success",
      driveFileUrl: fileUrl,
      driveFileId: fileId,
      message: "File berhasil disimpan di Google Drive & email konfirmasi terkirim."
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService.createTextOutput(JSON.stringify({
    status: "online",
    dosen: DOSEN_NAMA,
    email: DOSEN_EMAIL,
    timestamp: new Date().toISOString()
  })).setMimeType(ContentService.MimeType.JSON);
}
`;
};

export const dispatchSubmissionToGoogle = async (
  submission: Submission,
  assignment: Assignment,
  settings: LecturerSettings
): Promise<DispatchResult> => {
  // If webhook is provided, dispatch to Google Apps Script
  if (settings.googleAppsScriptWebhookUrl && settings.googleAppsScriptWebhookUrl.trim() !== '') {
    try {
      const payload = {
        ...submission,
        driveFolderId: assignment.driveFolderId || settings.googleDriveDefaultFolderId,
        waktuKirimFormatted: new Date(submission.waktuKirim).toLocaleString('id-ID', {
          timeZone: 'Asia/Jakarta',
          dateStyle: 'full',
          timeStyle: 'medium',
        }),
      };

      const response = await fetch(settings.googleAppsScriptWebhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8',
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();
      if (result.status === 'success') {
        return {
          success: true,
          driveFileUrl: result.driveFileUrl,
          driveFileId: result.driveFileId,
          emailSent: true,
          message: 'Berhasil dikirim ke Google Drive & Email konfirmasi telah dikirim via Gmail!',
        };
      }
    } catch (err: any) {
      console.warn('Google Webhook call failed, falling back to simulated storage:', err);
    }
  }

  // Graceful simulation fallback
  const simulatedDriveUrl = `https://drive.google.com/drive/folders/${assignment.driveFolderId || settings.googleDriveDefaultFolderId}`;
  return {
    success: true,
    driveFileUrl: simulatedDriveUrl,
    emailSent: settings.notifikasiEmailAktif,
    message: 'Tugas berhasil tercatat di database sistem pengumpulan.',
  };
};

export const createMailtoLink = (
  studentEmail: string,
  studentName: string,
  assignmentTitle: string,
  status: string,
  dosenNotes: string,
  settings: LecturerSettings
): string => {
  const subject = encodeURIComponent(`[UPDATE STATUS TUGAS] ${assignmentTitle} - ${studentName}`);
  const body = encodeURIComponent(
    `Kepada Yth. Sdr/i ${studentName},\n\n` +
    `Tugas Anda mengenai "${assignmentTitle}" telah diperiksa oleh Bapak ${settings.namaDosen}, ${settings.gelar}.\n\n` +
    `Status Tugas: ${status.toUpperCase()}\n` +
    `Catatan Dosen:\n${dosenNotes || 'Tidak ada catatan khusus.'}\n\n` +
    `Silakan kunjungi portal penugasan mahasiswa untuk detail lebih lanjut dan pengiriman revisi (jika diperlukan).\n\n` +
    `Salam hormat,\n${settings.namaDosen}, ${settings.gelar}\n${settings.kampus}`
  );
  return `mailto:${studentEmail}?subject=${subject}&body=${body}`;
};
