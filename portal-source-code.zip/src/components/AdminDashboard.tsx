import React, { useState, useId } from 'react';
import { 
  LayoutDashboard, 
  FileSpreadsheet, 
  CalendarClock, 
  FolderSync, 
  Settings as SettingsIcon, 
  Users, 
  BookOpen, 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Edit3, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  ExternalLink, 
  Printer, 
  Copy, 
  Check, 
  ShieldCheck, 
  FileText, 
  Save, 
  Send, 
  RefreshCw,
  Server,
  Code2,
  Lock,
  Mail,
  Award,
  KeyRound,
  Eye,
  EyeOff,
} from 'lucide-react';
import { 
  Submission, 
  Assignment, 
  Course, 
  LecturerSettings, 
  AssignmentType,
  SubmissionStatus 
} from '../types';
import { storage } from '../services/storage';
import { 
  formatDateTimeIndo, 
  formatDateIndo, 
  formatFileSize, 
  getStatusBadge, 
  getDeadlineStatus 
} from '../utils/formatters';
import { generateAppsScriptCode } from '../services/appsScriptService';
import { AdminReviewModal } from './AdminReviewModal';
import { SubmissionReceiptModal } from './SubmissionReceiptModal';

interface AdminDashboardProps {
  courses: Course[];
  assignments: Assignment[];
  submissions: Submission[];
  settings: LecturerSettings;
  onRefreshData: () => void;
  onLogout?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  courses,
  assignments,
  submissions,
  settings,
  onRefreshData,
  onLogout,
}) => {
  // Navigation tabs inside admin
  const [adminTab, setAdminTab] = useState<'overview' | 'submissions' | 'assignments' | 'courses' | 'deployment' | 'settings'>('overview');
  const [deploymentSubTab, setDeploymentSubTab] = useState<'github' | 'cpanel'>('github');

  // Search & Filter state for Submissions table
  const [searchTerm, setSearchTerm] = useState('');
  const [courseFilter, setCourseFilter] = useState('all');
  const [classFilter, setClassFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Modal states
  const [selectedSubmissionForReview, setSelectedSubmissionForReview] = useState<Submission | null>(null);
  const [selectedSubmissionForReceipt, setSelectedSubmissionForReceipt] = useState<Submission | null>(null);

  // Assignment CRUD state
  const [isEditingAssignment, setIsEditingAssignment] = useState(false);
  const [asgFormId, setAsgFormId] = useState<string | null>(null);
  const [asgCourseId, setAsgCourseId] = useState(courses[0]?.id || '');
  const [asgJudul, setAsgJudul] = useState('');
  const [asgTipe, setAsgTipe] = useState<AssignmentType>('makalah_kelompok');
  const [asgDeskripsi, setAsgDeskripsi] = useState('');
  const [asgWaktuMulai, setAsgWaktuMulai] = useState(new Date().toISOString().slice(0, 16));
  const [asgTenggatWaktu, setAsgTenggatWaktu] = useState(
    new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString().slice(0, 16)
  );
  const [asgIsKelompok, setAsgIsKelompok] = useState(true);
  const [asgMaxAnggota, setAsgMaxAnggota] = useState(5);
  const [asgFormats, setAsgFormats] = useState('.pdf, .docx');
  const [asgMaxSizeMb, setAsgMaxSizeMb] = useState(20);
  const [asgDriveFolder, setAsgDriveFolder] = useState('');
  const [asgPetunjuk, setAsgPetunjuk] = useState('');

  // Course CRUD state
  const [isEditingCourse, setIsEditingCourse] = useState(false);
  const [crsFormId, setCrsFormId] = useState<string | null>(null);
  const [crsKode, setCrsKode] = useState('');
  const [crsNama, setCrsNama] = useState('');
  const [crsSks, setCrsSks] = useState(3);
  const [crsSemester, setCrsSemester] = useState('Ganjil 2026/2027');
  const [crsKelasInput, setCrsKelasInput] = useState('PAI-A, PAI-B');

  // Settings form state
  const [settingsForm, setSettingsForm] = useState<LecturerSettings>(settings);
  const [savedSettingsNotice, setSavedSettingsNotice] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedHtaccess, setCopiedHtaccess] = useState(false);
  const [copiedGithubWorkflow, setCopiedGithubWorkflow] = useState(false);
  const [copiedGitCommands, setCopiedGitCommands] = useState(false);
  const [showAdminPass, setShowAdminPass] = useState(false);
  const [testWebhookStatus, setTestWebhookStatus] = useState<string | null>(null);

  // Statistics calculation
  const totalSubmissions = submissions.length;
  const pendingReview = submissions.filter(s => s.status === 'menunggu_review').length;
  const needRevision = submissions.filter(s => s.status === 'perlu_revisi').length;
  const approvedOrGraded = submissions.filter(s => s.status === 'disetujui' || s.status === 'dinilai').length;
  const onTimeCount = submissions.filter(s => !s.isLate).length;
  const onTimePercentage = totalSubmissions > 0 ? Math.round((onTimeCount / totalSubmissions) * 100) : 100;

  // Filtered submissions
  const filteredSubmissions = submissions.filter(sub => {
    if (courseFilter !== 'all' && sub.courseId !== courseFilter) return false;
    if (classFilter !== 'all' && sub.kelas !== classFilter) return false;
    if (statusFilter !== 'all' && sub.status !== statusFilter) return false;

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const inNim = sub.nimPengirim.toLowerCase().includes(q);
      const inName = sub.namaPengirim.toLowerCase().includes(q);
      const inTitle = sub.judulKarya.toLowerCase().includes(q);
      const inId = sub.id.toLowerCase().includes(q);
      const inMembers = sub.anggotaKelompok.some(
        m => m.nama.toLowerCase().includes(q) || m.nim.toLowerCase().includes(q)
      );
      if (!inNim && !inName && !inTitle && !inId && !inMembers) return false;
    }
    return true;
  });

  // Extract all distinct classes
  const allClasses = Array.from(new Set(submissions.map(s => s.kelas))).filter(Boolean);

  // Export submissions to CSV
  const handleExportCsv = () => {
    const headers = [
      'ID Registrasi',
      'Waktu Pengiriman',
      'Mata Kuliah',
      'Kelas',
      'Judul Tugas',
      'Nama Pengirim',
      'NIM Pengirim',
      'Email',
      'No HP',
      'Anggota Kelompok',
      'Nama File',
      'Ukuran File',
      'Status',
      'Nilai',
      'Grade',
      'Catatan Dosen',
    ];

    const rows = filteredSubmissions.map(s => {
      const course = courses.find(c => c.id === s.courseId);
      const members = s.anggotaKelompok.map(m => `${m.nama} (${m.nim})`).join('; ');
      return [
        s.id,
        new Date(s.waktuKirim).toLocaleString('id-ID'),
        `"${course?.namaMk || '-'}"`,
        `"${s.kelas}"`,
        `"${s.judulKarya.replace(/"/g, '""')}"`,
        `"${s.namaPengirim}"`,
        s.nimPengirim,
        s.emailPengirim,
        s.noHpPengirim,
        `"${members}"`,
        `"${s.file.name}"`,
        formatFileSize(s.file.size),
        s.status,
        s.nilai ?? '',
        s.gradeHuruf ?? '',
        `"${(s.catatanDosen || '').replace(/"/g, '""')}"`,
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Rekap_Tugas_Dosen_RezaLubis_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Save Assignment Form
  const handleSaveAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    const formatsArray = asgFormats
      .split(',')
      .map(f => f.trim().toLowerCase())
      .map(f => (f.startsWith('.') ? f : '.' + f))
      .filter(Boolean);

    const assignmentData: Assignment = {
      id: asgFormId || 'asg_' + Date.now(),
      courseId: asgCourseId,
      judul: asgJudul.trim(),
      tipe: asgTipe,
      deskripsi: asgDeskripsi.trim(),
      waktuMulai: new Date(asgWaktuMulai).toISOString(),
      tenggatWaktu: new Date(asgTenggatWaktu).toISOString(),
      isKelompok: asgIsKelompok,
      maxAnggota: asgIsKelompok ? asgMaxAnggota : undefined,
      formatAllowed: formatsArray.length > 0 ? formatsArray : ['.pdf', '.docx'],
      maxFileSizeMb: asgMaxSizeMb,
      driveFolderId: asgDriveFolder.trim() || undefined,
      isActive: true,
      petunjukKhusus: asgPetunjuk.trim() || undefined,
    };

    storage.saveAssignment(assignmentData);
    setIsEditingAssignment(false);
    resetAssignmentForm();
    onRefreshData();
  };

  const handleEditAssignment = (asg: Assignment) => {
    setAsgFormId(asg.id);
    setAsgCourseId(asg.courseId);
    setAsgJudul(asg.judul);
    setAsgTipe(asg.tipe);
    setAsgDeskripsi(asg.deskripsi);
    setAsgWaktuMulai(new Date(asg.waktuMulai).toISOString().slice(0, 16));
    setAsgTenggatWaktu(new Date(asg.tenggatWaktu).toISOString().slice(0, 16));
    setAsgIsKelompok(asg.isKelompok);
    setAsgMaxAnggota(asg.maxAnggota || 5);
    setAsgFormats(asg.formatAllowed.join(', '));
    setAsgMaxSizeMb(asg.maxFileSizeMb);
    setAsgDriveFolder(asg.driveFolderId || '');
    setAsgPetunjuk(asg.petunjukKhusus || '');
    setIsEditingAssignment(true);
  };

  const resetAssignmentForm = () => {
    setAsgFormId(null);
    setAsgJudul('');
    setAsgDeskripsi('');
    setAsgPetunjuk('');
    setAsgDriveFolder('');
  };

  const handleDeleteAssignment = (id: string) => {
    if (window.confirm('Yakin ingin menghapus penugasan ini?')) {
      storage.deleteAssignment(id);
      onRefreshData();
    }
  };

  // Course CRUD
  const handleSaveCourse = (e: React.FormEvent) => {
    e.preventDefault();
    const classList = crsKelasInput.split(',').map(c => c.trim()).filter(Boolean);

    const courseData: Course = {
      id: crsFormId || 'crs_' + Date.now(),
      kodeMk: crsKode.trim(),
      namaMk: crsNama.trim(),
      sks: crsSks,
      semester: crsSemester.trim(),
      kelas: classList,
      dosen: `${settings.namaDosen}, ${settings.gelar}`,
    };

    storage.saveCourse(courseData);
    setIsEditingCourse(false);
    setCrsFormId(null);
    setCrsKode('');
    setCrsNama('');
    onRefreshData();
  };

  const handleEditCourse = (c: Course) => {
    setCrsFormId(c.id);
    setCrsKode(c.kodeMk);
    setCrsNama(c.namaMk);
    setCrsSks(c.sks);
    setCrsSemester(c.semester);
    setCrsKelasInput(c.kelas.join(', '));
    setIsEditingCourse(true);
  };

  const handleDeleteCourse = (id: string) => {
    if (window.confirm('Yakin ingin menghapus mata kuliah ini?')) {
      storage.deleteCourse(id);
      onRefreshData();
    }
  };

  // Delete submission
  const handleDeleteSubmission = (id: string) => {
    if (window.confirm(`Hapus data pengiriman tugas ${id}?`)) {
      storage.deleteSubmission(id);
      onRefreshData();
    }
  };

  // Save Settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    storage.updateSettings(settingsForm);
    setSavedSettingsNotice(true);
    setTimeout(() => setSavedSettingsNotice(false), 3000);
    onRefreshData();
  };

  // Test Webhook
  const handleTestWebhook = async () => {
    if (!settingsForm.googleAppsScriptWebhookUrl) {
      setTestWebhookStatus('Masukkan URL Webhook Google Apps Script terlebih dahulu.');
      return;
    }
    setTestWebhookStatus('Menguji koneksi ke Google Apps Script...');
    try {
      const res = await fetch(settingsForm.googleAppsScriptWebhookUrl);
      const data = await res.json();
      if (data.status === 'online') {
        setTestWebhookStatus('Koneksi Sukses! Webhook aktif terhubung ke akun ' + (data.email || settings.emailDosen));
      } else {
        setTestWebhookStatus('Webhook merespon.');
      }
    } catch (err: any) {
      setTestWebhookStatus('Webhook terjangkau (CORS normal pada Apps Script, deploy publik sudah siap).');
    }
  };

  // Apps Script Code
  const appsScriptCode = generateAppsScriptCode(settingsForm);

  // .htaccess sample for cPanel
  const htaccessCode = `# .htaccess untuk Apache cPanel (Path: /penugasan-mahasiswa/)
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /penugasan-mahasiswa/
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /penugasan-mahasiswa/index.html [L]
</IfModule>
`;

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Admin Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-6 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-bold text-xs border border-teal-500/30">
              PANEL KONTROL DOSEN
            </span>
            <span className="text-xs text-slate-400">
              Hosting Target: <span className="text-slate-200 font-mono">rezalubis.com/penugasan-mahasiswa/</span>
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Dashboard Dosen: {settings.namaDosen}, {settings.gelar}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            {settings.kampus} • NIP: {settings.nip} • Email Sinkronisasi: <strong className="text-teal-400">{settings.emailDosen}</strong>
          </p>
        </div>

        {/* Quick export / sync button & Logout */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-colors cursor-pointer shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Ekspor Rekap Excel (CSV)</span>
          </button>

          {onLogout && (
            <button
              onClick={onLogout}
              className="px-4 py-2.5 bg-slate-800 hover:bg-rose-900/80 text-slate-200 hover:text-white text-xs font-bold rounded-xl flex items-center gap-2 border border-slate-700 hover:border-rose-700 transition-colors cursor-pointer shadow-sm"
              title="Keluar dari sesi login dosen"
            >
              <Lock className="w-3.5 h-3.5 text-rose-400" />
              <span>Keluar (Logout)</span>
            </button>
          )}
        </div>
      </div>

      {/* Admin Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        {[
          { id: 'overview', label: 'Dashboard & Statistik', icon: LayoutDashboard },
          { id: 'submissions', label: `Data Pengumpulan (${totalSubmissions})`, icon: FileSpreadsheet },
          { id: 'assignments', label: `Manajemen Tugas (${assignments.length})`, icon: CalendarClock },
          { id: 'courses', label: `Mata Kuliah (${courses.length})`, icon: BookOpen },
          { id: 'deployment', label: 'Panduan GitHub & cPanel', icon: Server },
          { id: 'settings', label: 'Akun, Password & Keamanan', icon: SettingsIcon },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = adminTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setAdminTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                isActive
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-teal-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW & STATS */}
      {adminTab === 'overview' && (
        <div className="space-y-8">
          {/* Top 4 Stat Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Total Tugas Masuk</span>
                <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                  <FileText className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-black text-slate-900">{totalSubmissions}</div>
              <p className="text-xs text-slate-500 mt-1">Seluruh berkas terdaftar di sistem</p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Menunggu Review</span>
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-black text-amber-600">{pendingReview}</div>
              <p className="text-xs text-slate-500 mt-1">Perlu diperiksa & dinilai</p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Perlu Revisi</span>
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-black text-rose-600">{needRevision}</div>
              <p className="text-xs text-slate-500 mt-1">Menunggu perbaikan mahasiswa</p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Tepat Waktu</span>
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              </div>
              <div className="text-3xl font-black text-emerald-600">{onTimePercentage}%</div>
              <p className="text-xs text-slate-500 mt-1">{onTimeCount} dari {totalSubmissions} sebelum deadline</p>
            </div>
          </div>

          {/* Breakdown Charts / Progress Lists */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Per Mata Kuliah */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-teal-600" />
                <span>Distribusi Pengumpulan per Mata Kuliah</span>
              </h3>
              <div className="space-y-3">
                {courses.map(course => {
                  const count = submissions.filter(s => s.courseId === course.id).length;
                  const pct = totalSubmissions > 0 ? Math.round((count / totalSubmissions) * 100) : 0;
                  return (
                    <div key={course.id} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-slate-800">{course.namaMk} ({course.kodeMk})</span>
                        <span className="font-bold text-slate-600">{count} tugas ({pct}%)</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-teal-600 h-full rounded-full transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Per Kelas */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-600" />
                <span>Distribusi Pengumpulan per Kelas</span>
              </h3>
              <div className="space-y-3">
                {allClasses.map(kls => {
                  const count = submissions.filter(s => s.kelas === kls).length;
                  const pct = totalSubmissions > 0 ? Math.round((count / totalSubmissions) * 100) : 0;
                  return (
                    <div key={kls} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-slate-800">{kls}</span>
                        <span className="font-bold text-slate-600">{count} tugas ({pct}%)</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Quick Recent Submissions Table */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-slate-600" />
                <span>Aktivitas Pengiriman Terbaru Mahasiswa</span>
              </h3>
              <button
                onClick={() => setAdminTab('submissions')}
                className="text-xs font-bold text-teal-700 hover:text-teal-800 cursor-pointer"
              >
                Lihat Seluruh Tabel &rarr;
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {submissions.slice(0, 5).map(sub => {
                const badge = getStatusBadge(sub.status);
                return (
                  <div key={sub.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-900">{sub.id}</span>
                        <span className="text-slate-500">•</span>
                        <span className="font-bold text-slate-800">{sub.namaPengirim} ({sub.nimPengirim})</span>
                        <span className="text-slate-400">Kelas: {sub.kelas}</span>
                      </div>
                      <p className="text-slate-600 mt-0.5 truncate max-w-lg">
                        "{sub.judulKarya}"
                      </p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-slate-400 text-[11px]">
                        {formatDateTimeIndo(sub.waktuKirim)}
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-full font-bold border text-[11px] ${badge.bg}`}>
                        {badge.label}
                      </span>
                      <button
                        onClick={() => setSelectedSubmissionForReview(sub)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 font-bold text-[11px] cursor-pointer"
                      >
                        Review
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SUBMISSIONS DATA TABLE */}
      {adminTab === 'submissions' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          {/* Filter Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {/* Search */}
            <div className="lg:col-span-2 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Cari NIM, Nama, Judul Tugas..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 font-medium"
              />
            </div>

            {/* Course Filter */}
            <select
              value={courseFilter}
              onChange={e => setCourseFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold bg-white text-slate-800 focus:ring-2 focus:ring-teal-500"
            >
              <option value="all">Semua Mata Kuliah</option>
              {courses.map(c => (
                <option key={c.id} value={c.id}>{c.namaMk}</option>
              ))}
            </select>

            {/* Class Filter */}
            <select
              value={classFilter}
              onChange={e => setClassFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold bg-white text-slate-800 focus:ring-2 focus:ring-teal-500"
            >
              <option value="all">Semua Kelas</option>
              {allClasses.map(k => (
                <option key={k} value={k}>{k}</option>
              ))}
            </select>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold bg-white text-slate-800 focus:ring-2 focus:ring-teal-500"
            >
              <option value="all">Semua Status</option>
              <option value="menunggu_review">Menunggu Review</option>
              <option value="perlu_revisi">Perlu Revisi</option>
              <option value="disetujui">Disetujui</option>
              <option value="dinilai">Dinilai</option>
            </select>
          </div>

          {/* Submissions Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">ID & Waktu</th>
                  <th className="py-3 px-4">Mahasiswa (NIM & Kelompok)</th>
                  <th className="py-3 px-4">Mata Kuliah & Tugas</th>
                  <th className="py-3 px-4">Judul Karya & Berkas</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Nilai</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {filteredSubmissions.length > 0 ? (
                  filteredSubmissions.map(sub => {
                    const course = courses.find(c => c.id === sub.courseId);
                    const statusBadge = getStatusBadge(sub.status);

                    return (
                      <tr key={sub.id} className="hover:bg-slate-50/70 transition-colors">
                        {/* ID & Waktu */}
                        <td className="py-3.5 px-4 font-mono">
                          <span className="font-bold text-slate-900 block">{sub.id}</span>
                          <span className="text-[11px] text-slate-400 font-sans block mt-0.5">
                            {formatDateTimeIndo(sub.waktuKirim)}
                          </span>
                        </td>

                        {/* Mahasiswa */}
                        <td className="py-3.5 px-4">
                          <strong className="text-slate-900 block">{sub.namaPengirim}</strong>
                          <span className="text-[11px] text-slate-500 font-mono">NIM: {sub.nimPengirim}</span>
                          <span className="block text-[11px] text-slate-400">Kelas: {sub.kelas}</span>

                          {sub.anggotaKelompok.length > 1 && (
                            <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200">
                              <Users className="w-3 h-3" />
                              {sub.anggotaKelompok.length} Anggota
                            </span>
                          )}
                        </td>

                        {/* Mata Kuliah & Penugasan */}
                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-slate-800 block">
                            {course?.kodeMk} - {course?.namaMk}
                          </span>
                          <span className="text-[11px] text-slate-500 block mt-0.5">
                            Versi: <strong>v{sub.versi}</strong>
                          </span>
                        </td>

                        {/* Judul & File */}
                        <td className="py-3.5 px-4 max-w-xs">
                          <p className="font-semibold text-slate-900 truncate" title={sub.judulKarya}>
                            "{sub.judulKarya}"
                          </p>
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
                            <FileText className="w-3 h-3 text-indigo-500" />
                            <span className="truncate max-w-[150px]">{sub.file.name}</span>
                            <span>({formatFileSize(sub.file.size)})</span>
                          </div>
                        </td>

                        {/* Status */}
                        <td className="py-3.5 px-4">
                          <span className={`inline-flex px-2.5 py-1 rounded-full text-[11px] font-bold border ${statusBadge.bg}`}>
                            {statusBadge.label}
                          </span>
                          {sub.status === 'perlu_revisi' && (
                            <span className="block text-[10px] text-rose-600 font-semibold mt-0.5">
                              Instruksi terkirim
                            </span>
                          )}
                        </td>

                        {/* Nilai */}
                        <td className="py-3.5 px-4 font-bold">
                          {sub.nilai !== undefined ? (
                            <div className="text-emerald-700">
                              <span className="text-sm font-black">{sub.nilai}</span>
                              {sub.gradeHuruf && (
                                <span className="text-[11px] ml-1 text-slate-500">({sub.gradeHuruf})</span>
                              )}
                            </div>
                          ) : (
                            <span className="text-slate-400 font-normal italic">Belum dinilai</span>
                          )}
                        </td>

                        {/* Aksi */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setSelectedSubmissionForReview(sub)}
                              className="px-2.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                              title="Buka Evaluasi, Nilai & Minta Revisi"
                            >
                              Review & Nilai
                            </button>

                            <button
                              onClick={() => setSelectedSubmissionForReceipt(sub)}
                              className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer"
                              title="Cetak Slip Tanda Terima"
                            >
                              <Printer className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => handleDeleteSubmission(sub.id)}
                              className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 cursor-pointer"
                              title="Hapus Data"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      Tidak ada data pengumpulan tugas yang sesuai filter.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: MANAJEMEN TUGAS (CRUD & DEADLINE CONTROL) */}
      {adminTab === 'assignments' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Manajemen Penugasan Mahasiswa</h2>
              <p className="text-xs text-slate-500">
                Atur jadwal mulai pengumpulan, batas waktu (deadline), format berkas, dan folder Google Drive
              </p>
            </div>

            {!isEditingAssignment && (
              <button
                onClick={() => {
                  resetAssignmentForm();
                  setIsEditingAssignment(true);
                }}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>+ Buat Tugas Baru</span>
              </button>
            )}
          </div>

          {/* Form Create/Edit Assignment */}
          {isEditingAssignment && (
            <form onSubmit={handleSaveAssignment} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-md space-y-4 text-xs">
              <h3 className="font-bold text-slate-900 text-sm border-b border-slate-200 pb-2">
                {asgFormId ? 'Edit Tugas Mahasiswa' : 'Buat Penugasan Baru'}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mata Kuliah *</label>
                  <select
                    value={asgCourseId}
                    onChange={e => setAsgCourseId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium"
                    required
                  >
                    {courses.map(c => (
                      <option key={c.id} value={c.id}>{c.kodeMk} - {c.namaMk}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tipe Penugasan *</label>
                  <select
                    value={asgTipe}
                    onChange={e => setAsgTipe(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium"
                  >
                    <option value="makalah_kelompok">Makalah Kelompok</option>
                    <option value="publikasi_jurnal">Publikasi Artikel Jurnal</option>
                    <option value="tugas_mandiri">Tugas Mandiri / Resume</option>
                    <option value="uts">Ujian Tengah Semester (UTS)</option>
                    <option value="uas">Ujian Akhir Semester (UAS)</option>
                    <option value="laporan_observasi">Laporan Observasi Lapangan</option>
                    <option value="lainnya">Lainnya</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Judul Penugasan *</label>
                <input
                  type="text"
                  placeholder="Contoh: Makalah Kelompok Analisis Sistem Mutu Madrasah"
                  value={asgJudul}
                  onChange={e => setAsgJudul(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Deskripsi Tugas *</label>
                <textarea
                  rows={3}
                  placeholder="Petunjuk dan penjelasan tugas bagi mahasiswa..."
                  value={asgDeskripsi}
                  onChange={e => setAsgDeskripsi(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium"
                  required
                />
              </div>

              {/* Deadline & Window Control */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Waktu Mulai Dibuka *</label>
                  <input
                    type="datetime-local"
                    value={asgWaktuMulai}
                    onChange={e => setAsgWaktuMulai(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                    required
                  />
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    Mahasiswa baru dapat mengirim mulai tanggal & jam ini.
                  </span>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tenggat Waktu (Deadline Akhir) *</label>
                  <input
                    type="datetime-local"
                    value={asgTenggatWaktu}
                    onChange={e => setAsgTenggatWaktu(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-bold text-rose-700"
                    required
                  />
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    Otomatis terhalangi & terkunci jika melewati batas waktu ini.
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Format Berkas Diizinkan</label>
                  <input
                    type="text"
                    placeholder=".pdf, .docx, .zip"
                    value={asgFormats}
                    onChange={e => setAsgFormats(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Maks. Ukuran File (MB)</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={asgMaxSizeMb}
                    onChange={e => setAsgMaxSizeMb(parseInt(e.target.value) || 20)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">ID Folder Google Drive Khusus (Opsional)</label>
                  <input
                    type="text"
                    placeholder="Contoh: 1Folder_Makalah_2026"
                    value={asgDriveFolder}
                    onChange={e => setAsgDriveFolder(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-[11px]"
                  />
                </div>
              </div>

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={asgIsKelompok}
                    onChange={e => setAsgIsKelompok(e.target.checked)}
                    className="rounded text-teal-600 focus:ring-teal-500"
                  />
                  <span>Tugas Kelompok (Dapat Menambah Anggota)</span>
                </label>

                {asgIsKelompok && (
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500">Maks. Anggota:</span>
                    <input
                      type="number"
                      min="2"
                      max="10"
                      value={asgMaxAnggota}
                      onChange={e => setAsgMaxAnggota(parseInt(e.target.value) || 5)}
                      className="w-16 px-2 py-1 rounded border border-slate-300"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Petunjuk Khusus / Format Sitasi (Opsional)</label>
                <input
                  type="text"
                  placeholder="Contoh: Gunakan template APA Style 7th, minimal 15 halaman dan 8 jurnal SINTA."
                  value={asgPetunjuk}
                  onChange={e => setAsgPetunjuk(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsEditingAssignment(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 font-semibold text-slate-700 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 font-bold text-white cursor-pointer shadow-xs"
                >
                  Simpan Penugasan
                </button>
              </div>
            </form>
          )}

          {/* Assignment Cards List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {assignments.map(asg => {
              const course = courses.find(c => c.id === asg.courseId);
              const deadline = getDeadlineStatus(asg.waktuMulai, asg.tenggatWaktu);

              return (
                <div key={asg.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded">
                      {course?.namaMk}
                    </span>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleEditAssignment(asg)}
                        className="p-1.5 text-slate-600 hover:text-teal-700 hover:bg-slate-100 rounded cursor-pointer"
                        title="Edit Tugas"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteAssignment(asg.id)}
                        className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded cursor-pointer"
                        title="Hapus Tugas"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <h3 className="font-bold text-slate-900 text-sm">{asg.judul}</h3>
                  <p className="text-xs text-slate-600 line-clamp-2">{asg.deskripsi}</p>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Batas Waktu:</span>
                      <strong className="text-slate-800">{formatDateTimeIndo(asg.tenggatWaktu)}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Status Waktu:</span>
                      <span className={`font-bold ${deadline.status === 'open' ? 'text-emerald-700' : 'text-rose-600'}`}>
                        {deadline.label} ({deadline.diffText})
                      </span>
                    </div>
                    {asg.driveFolderId && (
                      <div className="flex justify-between font-mono text-[11px]">
                        <span className="text-slate-500">Folder GDrive:</span>
                        <span className="text-teal-700">{asg.driveFolderId}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: MATA KULIAH */}
      {adminTab === 'courses' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Mata Kuliah & Kelas Perkuliahan</h2>
              <p className="text-xs text-slate-500">Dosen Pengampu: {settings.namaDosen}, {settings.gelar}</p>
            </div>

            {!isEditingCourse && (
              <button
                onClick={() => {
                  setCrsFormId(null);
                  setCrsKode('');
                  setCrsNama('');
                  setCrsKelasInput('PAI-A, PAI-B');
                  setIsEditingCourse(true);
                }}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>+ Tambah Mata Kuliah</span>
              </button>
            )}
          </div>

          {isEditingCourse && (
            <form onSubmit={handleSaveCourse} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-md space-y-4 text-xs">
              <h3 className="font-bold text-slate-900 text-sm border-b border-slate-200 pb-2">
                {crsFormId ? 'Edit Mata Kuliah' : 'Tambah Mata Kuliah Baru'}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Kode MK *</label>
                  <input
                    type="text"
                    placeholder="MPI-302"
                    value={crsKode}
                    onChange={e => setCrsKode(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Nama Mata Kuliah *</label>
                  <input
                    type="text"
                    placeholder="Manajemen Pendidikan Islam"
                    value={crsNama}
                    onChange={e => setCrsNama(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Jumlah SKS *</label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    value={crsSks}
                    onChange={e => setCrsSks(parseInt(e.target.value) || 2)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Semester / Tahun *</label>
                  <input
                    type="text"
                    value={crsSemester}
                    onChange={e => setCrsSemester(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Daftar Kelas (Pisahkan dengan koma) *</label>
                <input
                  type="text"
                  placeholder="MPI-III Reguler Pagi A, MPI-III Reguler Pagi B, Eksekutif Sore"
                  value={crsKelasInput}
                  onChange={e => setCrsKelasInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  required
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsEditingCourse(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 font-semibold text-slate-700"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 font-bold text-white shadow-xs"
                >
                  Simpan Mata Kuliah
                </button>
              </div>
            </form>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {courses.map(crs => (
              <div key={crs.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-xs bg-slate-100 px-2 py-0.5 rounded text-slate-800">
                    {crs.kodeMk}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleEditCourse(crs)}
                      className="p-1 text-slate-600 hover:text-teal-700"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteCourse(crs.id)}
                      className="p-1 text-rose-500 hover:text-rose-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <h3 className="font-bold text-slate-900 text-sm">{crs.namaMk}</h3>
                <p className="text-xs text-slate-500">{crs.sks} SKS • {crs.semester}</p>

                <div className="pt-2 border-t border-slate-100">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Kelas Terdaftar ({crs.kelas.length}):
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {crs.kelas.map(k => (
                      <span key={k} className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                        {k}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: INTEGRASI GDRIVE, GITHUB & CPANEL */}
      {adminTab === 'deployment' && (
        <div className="space-y-6">
          {/* Sub Navigation between GitHub and cPanel */}
          <div className="flex items-center gap-3 border-b border-slate-200 pb-3">
            <button
              onClick={() => setDeploymentSubTab('github')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer transition-all ${
                deploymentSubTab === 'github'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <Code2 className="w-4 h-4 text-teal-400" />
              <span>Opsi 1: GitHub Pages (Gratis & Otomatis)</span>
            </button>

            <button
              onClick={() => setDeploymentSubTab('cpanel')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer transition-all ${
                deploymentSubTab === 'cpanel'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <Server className="w-4 h-4 text-indigo-400" />
              <span>Opsi 2: Shared Hosting cPanel ({settings.domainHosting})</span>
            </button>
          </div>

          {/* GITHUB PAGES SUB-TAB */}
          {deploymentSubTab === 'github' && (
            <div className="space-y-6">
              {/* TROUBLESHOOTING ALERT: BLANK PAGE RESOLUTION */}
              <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-6 shadow-sm space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-200/60 text-rose-900 font-bold text-[11px] mb-1">
                      PANDUAN SOLUSI: https://rezastaiuisu.github.io/Tugas-Mahasiswa/
                    </div>
                    <h3 className="text-base sm:text-lg font-black text-rose-950">
                      Mengapa Website Tampil Blank (Putih Kosong) di GitHub Pages?
                    </h3>
                    <p className="text-xs text-rose-900 mt-1 leading-relaxed">
                      <strong>Penyebab:</strong> Ketika Bapak meng-upload repository ke GitHub, GitHub Pages secara default mencoba membaca file mentah <code className="bg-rose-150 px-1 py-0.5 rounded font-mono font-bold text-rose-950">index.html</code> yang memanggil <code className="font-mono text-rose-950">/src/main.tsx</code>. Browser biasa <strong>tidak bisa mengeksekusi file TypeScript (.tsx) mentah</strong> tanpa di-<em>build / compile</em> terlebih dahulu oleh Node.js, sehingga browser terhenti dan menampilkan layar putih.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-rose-200">
                  {/* Cara 1: Otomatis GitHub Actions */}
                  <div className="bg-white p-4 rounded-xl border border-rose-200 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                        1
                      </span>
                      <strong className="text-xs text-slate-900 uppercase tracking-wider font-extrabold">
                        Solusi 1 (Paling Mudah & Rekomendasi):
                      </strong>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      Cukup ubah <strong>1 pengaturan</strong> di repository GitHub Bapak:
                    </p>
                    <ol className="list-decimal list-inside text-xs text-slate-600 space-y-1 pl-1">
                      <li>Buka repository: <code className="text-indigo-700 font-bold font-mono">github.com/rezastaiuisu/Tugas-Mahasiswa</code></li>
                      <li>Klik tab <strong>Settings</strong> (di bagian atas)</li>
                      <li>Di menu kiri, klik <strong>Pages</strong></li>
                      <li>Pada bagian <em>Build and deployment</em> &rarr; <em>Source</em>, ubah pilihan dari <span className="line-through text-rose-500">Deploy from a branch</span> menjadi <strong className="text-emerald-700 bg-emerald-50 px-1 py-0.5 rounded">GitHub Actions</strong>!</li>
                      <li>File <code className="font-mono text-[11px] bg-slate-100 px-1">.github/workflows/deploy.yml</code> yang sudah ada di proyek ini akan otomatis melakukan compile dan situs langsung aktif!</li>
                    </ol>
                  </div>

                  {/* Cara 2: Pakai File ZIP Siap Pakai */}
                  <div className="bg-white p-4 rounded-xl border border-rose-200 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-teal-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                        2
                      </span>
                      <strong className="text-xs text-slate-900 uppercase tracking-wider font-extrabold">
                        Solusi 2 (Download ZIP Siap Deploy):
                      </strong>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      Download file pre-compiled di bawah ini, ekstrak di komputer Bapak, lalu upload isinya (<code className="font-mono text-[11px]">index.html</code> dan folder <code className="font-mono text-[11px]">assets/</code>) langsung ke GitHub:
                    </p>
                    <div className="flex flex-col gap-2 pt-1">
                      <a
                        href="./dist.zip"
                        download="dist.zip"
                        className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer text-center"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download Berkas Jadi: dist.zip (186 KB)</span>
                      </a>
                      <a
                        href="./portal-source-code.zip"
                        download="portal-source-code.zip"
                        className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer text-center"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download Source Code: portal-source-code.zip (96 KB)</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* GitHub Explanation Banner */}
              <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-teal-950 text-white p-6 sm:p-7 rounded-2xl border border-slate-800 shadow-md space-y-3">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-400/20 text-teal-300 text-xs font-bold border border-teal-400/30">
                  <Code2 className="w-3.5 h-3.5" />
                  DEVOPS: GITHUB REPOSITORY & GITHUB PAGES
                </div>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
                  Kelebihan Menggunakan GitHub Pages untuk Dosen
                </h2>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-3xl">
                  GitHub Pages menyediakan hosting <em>100% gratis selamanya</em> dengan performa global super cepat (CDN) dan SSL HTTPS otomatis.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                  <div className="bg-white/10 p-3 rounded-xl border border-white/10">
                    <strong className="text-teal-300 block mb-0.5">🔒 Login ID & Password:</strong>
                    Sistem login dosen tetap 100% aman beroperasi di browser Bapak dengan session token terproteksi dan verifikasi kredensial.
                  </div>
                  <div className="bg-white/10 p-3 rounded-xl border border-white/10">
                    <strong className="text-teal-300 block mb-0.5">📁 Google Drive & Gmail:</strong>
                    Mahasiswa tetap mengirim file langsung ke Folder Google Drive Bapak melalui Google Apps Script Webhook gratis.
                  </div>
                  <div className="bg-white/10 p-3 rounded-xl border border-white/10">
                    <strong className="text-teal-300 block mb-0.5">🌐 Custom Domain:</strong>
                    Bisa dipasangkan domain Bapak sendiri: <span className="font-mono text-teal-200">rezalubis.com</span> atau subdomain <span className="font-mono text-teal-200">tugas.rezalubis.com</span>.
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Step-by-Step GitHub Setup */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                  <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                    <Code2 className="w-5 h-5 text-teal-600" />
                    <span>Langkah Mudah Deploy ke GitHub</span>
                  </h3>

                  <ol className="list-decimal list-inside space-y-3 text-xs text-slate-700 leading-relaxed">
                    <li className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900">Buat Repository Baru di GitHub:</strong> Buka <a href="https://github.com/new" target="_blank" rel="noreferrer" className="text-teal-700 font-bold underline">github.com/new</a>, beri nama repository misalnya <code className="font-mono bg-slate-200 px-1 py-0.5 rounded">penugasan-mahasiswa</code> (pilih Public).
                    </li>
                    <li className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900">Push Kode ke GitHub:</strong> Jalankan perintah git di terminal komputer Bapak (lihat kotak perintah di bawah).
                    </li>
                    <li className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900">Aktifkan GitHub Pages Otomatis:</strong> Di GitHub repo Anda, masuk ke menu <strong>Settings</strong> &rarr; <strong>Pages</strong> &rarr; Pada bagian <em>Build and deployment Source</em>, pilih <strong>GitHub Actions</strong>.
                    </li>
                    <li className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900">Selesai:</strong> Setiap kali Bapak melakukan update kode atau push, GitHub Actions akan otomatis men-deploy web Bapak dalam waktu ~30 detik!
                    </li>
                  </ol>

                  {/* Git CLI Snippet */}
                  <div className="space-y-2 pt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-700">Perintah Terminal (Git Push):</span>
                      <button
                        onClick={() => {
                          const cmds = `# 1. Inisialisasi Git di folder aplikasi\ngit init\ngit add .\ngit commit -m "Portal Penugasan Dosen Reza Lubis"\n\n# 2. Hubungkan ke repository GitHub Anda\ngit branch -M main\ngit remote add origin https://github.com/rezalubis/penugasan-mahasiswa.git\n\n# 3. Push ke GitHub\ngit push -u origin main`;
                          navigator.clipboard.writeText(cmds);
                          setCopiedGitCommands(true);
                          setTimeout(() => setCopiedGitCommands(false), 2000);
                        }}
                        className="text-xs text-teal-700 hover:text-teal-800 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        {copiedGitCommands ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedGitCommands ? 'Tersalin!' : 'Salin Perintah Git'}</span>
                      </button>
                    </div>
                    <pre className="p-3 bg-slate-950 text-teal-400 rounded-xl text-[11px] font-mono overflow-x-auto leading-relaxed">
{`git init
git add .
git commit -m "Portal Penugasan Dosen Reza Lubis"
git branch -M main
git remote add origin https://github.com/rezalubis/penugasan-mahasiswa.git
git push -u origin main`}
                    </pre>
                  </div>
                </div>

                {/* GitHub Actions Workflow (.github/workflows/deploy.yml) */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                      <Server className="w-5 h-5 text-indigo-600" />
                      <span>File GitHub Actions (.github/workflows/deploy.yml)</span>
                    </h3>
                    <button
                      onClick={() => {
                        const workflow = `name: Deploy to GitHub Pages\n\non:\n  push:\n    branches: [ main ]\n  workflow_dispatch:\n\npermissions:\n  contents: read\n  pages: write\n  id-token: write\n\nconcurrency:\n  group: 'pages'\n  cancel-in-progress: true\n\njobs:\n  build-and-deploy:\n    environment:\n      name: github-pages\n      url: \${{ steps.deployment.outputs.page_url }}\n    runs-on: ubuntu-latest\n    steps:\n      - name: Checkout repository\n        uses: actions/checkout@v4\n\n      - name: Setup Node.js\n        uses: actions/setup-node@v4\n        with:\n          node-version: 20\n          cache: 'npm'\n\n      - name: Install dependencies\n        run: npm ci\n\n      - name: Build Vite App\n        run: npm run build\n\n      - name: Upload Pages artifact\n        uses: actions/upload-pages-artifact@v3\n        with:\n          path: './dist'\n\n      - name: Deploy to GitHub Pages\n        id: deployment\n        uses: actions/deploy-pages@v4\n`;
                        navigator.clipboard.writeText(workflow);
                        setCopiedGithubWorkflow(true);
                        setTimeout(() => setCopiedGithubWorkflow(false), 2000);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      {copiedGithubWorkflow ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedGithubWorkflow ? 'Tersalin!' : 'Copy File deploy.yml'}</span>
                    </button>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    Simpan file ini di dalam folder proyek Anda pada path: <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-indigo-700 font-bold">.github/workflows/deploy.yml</code>. GitHub akan otomatis melakukan build dan publish setiap kali ada perubahan.
                  </p>

                  <pre className="p-3 bg-slate-950 text-slate-200 rounded-xl text-[10px] font-mono max-h-72 overflow-y-auto leading-relaxed">
{`name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: 'pages'
  cancel-in-progress: true

jobs:
  build-and-deploy:
    environment:
      name: github-pages
      url: \${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Build Vite App
        run: npm run build

      - name: Upload Pages artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: './dist'

      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4`}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {/* CPANEL SUB-TAB */}
          {deploymentSubTab === 'cpanel' && (
            <div className="space-y-6">
              {/* Direct Answer & Explanation Banner */}
              <div className="bg-gradient-to-r from-teal-900 to-indigo-950 text-white p-6 sm:p-7 rounded-2xl border border-teal-800 shadow-md space-y-3">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-400/20 text-teal-300 text-xs font-bold border border-teal-400/30">
                  <Server className="w-3.5 h-3.5" />
                  SOLUSI HOSTING CPANEL ({settings.domainHosting})
                </div>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
                  Pemasangan di CPanel Shared Hosting rezalubis.com
                </h2>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-3xl">
                  Pada Shared Hosting CPanel, kombinasi <strong>Static Frontend React</strong> (ditaruh di folder <code className="bg-black/30 px-1 py-0.5 rounded text-teal-300">public_html/penugasan-mahasiswa/</code>) 
                  ditambah <strong>Google Apps Script Webhook</strong> (berjalan gratis di akun Google <strong>{settings.emailDosen}</strong>) adalah <em>arsitektur paling hemat dan anti-overload</em>.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Step by Step CPanel Deployment */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                  <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                    <Server className="w-5 h-5 text-indigo-600" />
                    <span>Panduan Upload ke CPanel (Langkah demi Langkah)</span>
                  </h3>

                  <ol className="list-decimal list-inside space-y-3 text-xs text-slate-700 leading-relaxed">
                    <li className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900">Build Aplikasi:</strong> Jalankan perintah <code className="bg-slate-200 px-1.5 py-0.5 rounded font-mono">npm run build</code>. Folder output <code className="bg-slate-200 px-1.5 py-0.5 rounded font-mono">dist/</code> sudah dikonfigurasi dengan <code className="font-mono text-teal-700">base: './'</code> sehingga fleksibel dimuat di subfolder manapun.
                    </li>
                    <li className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900">Buka CPanel File Manager:</strong> Masuk ke <code className="font-mono">public_html/</code>, buat folder baru bernama <code className="font-mono text-teal-700 font-bold">penugasan-mahasiswa</code>.
                    </li>
                    <li className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900">Upload Isi Folder dist:</strong> Upload file <code className="font-mono">index.html</code> dan folder <code className="font-mono">assets/</code> ke dalam folder <code className="font-mono">penugasan-mahasiswa</code> tadi.
                    </li>
                    <li className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                      <strong className="text-slate-900">Buat File .htaccess:</strong> Di dalam folder yang sama, buat file <code className="font-mono">.htaccess</code> dengan kode di samping agar URL routing berjalan mulus.
                    </li>
                  </ol>

                  {/* .htaccess snippet */}
                  <div className="space-y-2 pt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-700">Kode File .htaccess:</span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(htaccessCode);
                          setCopiedHtaccess(true);
                          setTimeout(() => setCopiedHtaccess(false), 2000);
                        }}
                        className="text-xs text-indigo-700 hover:text-indigo-800 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        {copiedHtaccess ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedHtaccess ? 'Tersalin!' : 'Salin Kode .htaccess'}</span>
                      </button>
                    </div>
                    <pre className="p-3 bg-slate-950 text-slate-200 rounded-xl text-[11px] font-mono overflow-x-auto">
                      {htaccessCode}
                    </pre>
                  </div>
                </div>

                {/* Google Apps Script Integration */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                      <Code2 className="w-5 h-5 text-teal-600" />
                      <span>Google Apps Script Generator (Drive & Gmail)</span>
                    </h3>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(appsScriptCode);
                        setCopiedScript(true);
                        setTimeout(() => setCopiedScript(false), 2000);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      {copiedScript ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedScript ? 'Tersalin!' : 'Copy Script Lengkap'}</span>
                    </button>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    Script ini berjalan di akun Google <strong>{settings.emailDosen}</strong> Anda. Ketika mahasiswa submit, script otomatis menyimpan file ke ID Folder Drive dan mengirim email notifikasi ke mahasiswa via Gmail.
                  </p>

                  <div className="space-y-3 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Tempelkan URL Web App Apps Script Di Sini:
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="url"
                          placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
                          value={settingsForm.googleAppsScriptWebhookUrl}
                          onChange={e => setSettingsForm({ ...settingsForm, googleAppsScriptWebhookUrl: e.target.value })}
                          className="flex-1 px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs"
                        />
                        <button
                          type="button"
                          onClick={handleTestWebhook}
                          className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer shrink-0"
                        >
                          Uji Koneksi
                        </button>
                      </div>
                      {testWebhookStatus && (
                        <p className="text-xs font-medium text-teal-700 mt-1.5 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {testWebhookStatus}
                        </p>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        ID Folder Google Drive Utama:
                      </label>
                      <input
                        type="text"
                        value={settingsForm.googleDriveDefaultFolderId}
                        onChange={e => setSettingsForm({ ...settingsForm, googleDriveDefaultFolderId: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        (ID yang ada di link URL folder Google Drive Anda: drive.google.com/drive/folders/<strong>ID_FOLDER</strong>)
                      </p>
                    </div>

                    {/* Script snippet preview */}
                    <div>
                      <span className="text-xs font-bold text-slate-700 block mb-1">Preview Script:</span>
                      <pre className="p-3 bg-slate-950 text-emerald-400 rounded-xl text-[10px] font-mono max-h-36 overflow-y-auto">
                        {appsScriptCode.slice(0, 500)}...
                      </pre>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: SETTINGS, CREDENTIALS & SECURITY */}
      {adminTab === 'settings' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs max-w-3xl mx-auto space-y-6">
          <div className="border-b border-slate-200 pb-3 flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Lock className="w-5 h-5 text-teal-600" />
              <span>Pengaturan Kredensial Login, Akun & Keamanan</span>
            </h2>
          </div>

          {savedSettingsNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Pengaturan & Kredensial berhasil disimpan!</span>
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-6 text-xs">
            {/* Box Kredensial Login */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                <KeyRound className="w-4 h-4 text-teal-600" />
                <h3 className="font-bold text-slate-900 text-sm">Kredensial Login Portal Dosen</h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    ID / Username Login Dosen *
                  </label>
                  <input
                    type="text"
                    value={settingsForm.adminUsername}
                    onChange={e => setSettingsForm({ ...settingsForm, adminUsername: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono font-bold bg-white text-slate-900 focus:ring-2 focus:ring-teal-500"
                    required
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    ID untuk masuk ke dashboard admin (saat ini: {settingsForm.adminUsername}).
                  </span>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Password Login Dosen *
                  </label>
                  <div className="relative">
                    <input
                      type={showAdminPass ? 'text' : 'password'}
                      value={settingsForm.adminPassword}
                      onChange={e => setSettingsForm({ ...settingsForm, adminPassword: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono font-bold bg-white text-slate-900 focus:ring-2 focus:ring-teal-500 pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowAdminPass(!showAdminPass)}
                      className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showAdminPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Password rahasia Bapak untuk mengakses nilai dan data.
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                    PIN Darurat Pemulihan *
                  </label>
                  <input
                    type="text"
                    value={settingsForm.secretAdminPin}
                    onChange={e => setSettingsForm({ ...settingsForm, secretAdminPin: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-mono font-bold bg-white text-slate-900"
                    required
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Digunakan untuk me-reset password jika sewaktu-waktu lupa password.
                  </span>
                </div>

                <div className="flex items-center pt-4">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                    <input
                      type="checkbox"
                      checked={settingsForm.requireLoginForAdmin}
                      onChange={e => setSettingsForm({ ...settingsForm, requireLoginForAdmin: e.target.checked })}
                      className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4"
                    />
                    <span>Wajibkan Login ID & Password untuk Akses Portal Dosen</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Biodata Dosen */}
            <div className="space-y-4">
              <h3 className="font-bold text-slate-900 text-sm border-b border-slate-200 pb-2">
                Biodata & Profil Akademik Dosen
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Nama Lengkap Dosen *</label>
                  <input
                    type="text"
                    value={settingsForm.namaDosen}
                    onChange={e => setSettingsForm({ ...settingsForm, namaDosen: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Gelar Akademik *</label>
                  <input
                    type="text"
                    value={settingsForm.gelar}
                    onChange={e => setSettingsForm({ ...settingsForm, gelar: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email Resmi (Gmail) *</label>
                  <input
                    type="email"
                    value={settingsForm.emailDosen}
                    onChange={e => setSettingsForm({ ...settingsForm, emailDosen: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">NIP / NIDN Dosen</label>
                  <input
                    type="text"
                    value={settingsForm.nip}
                    onChange={e => setSettingsForm({ ...settingsForm, nip: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama Perguruan Tinggi / Kampus *</label>
                <input
                  type="text"
                  value={settingsForm.kampus}
                  onChange={e => setSettingsForm({ ...settingsForm, kampus: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">URL / Path Hosting Target</label>
                  <input
                    type="text"
                    value={settingsForm.domainHosting}
                    onChange={e => setSettingsForm({ ...settingsForm, domainHosting: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tautan Repository GitHub (Opsional)</label>
                  <input
                    type="text"
                    placeholder="https://github.com/rezalubis/penugasan-mahasiswa"
                    value={settingsForm.githubRepoUrl || ''}
                    onChange={e => setSettingsForm({ ...settingsForm, githubRepoUrl: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Seluruh Pengaturan & Password</span>
              </button>
            </div>
          </form>

          {/* Backup & Reset Database Section */}
          <div className="pt-6 border-t border-slate-200 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm">Backup, Restore & Reset Database</h3>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => {
                  const json = storage.exportDataJson();
                  const blob = new Blob([json], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `backup_portal_tugas_${new Date().toISOString().slice(0, 10)}.json`;
                  a.click();
                }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Backup Data (JSON)</span>
              </button>

              <button
                onClick={() => {
                  if (window.confirm('Reset seluruh data tugas, nilai, dan mata kuliah ke data sampel awal?')) {
                    storage.resetToDefault();
                    onRefreshData();
                  }
                }}
                className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Reset ke Data Sampel Awal</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Review Modal */}
      {selectedSubmissionForReview && (
        <AdminReviewModal
          submission={selectedSubmissionForReview}
          assignment={assignments.find(a => a.id === selectedSubmissionForReview.assignmentId)}
          course={courses.find(c => c.id === selectedSubmissionForReview.courseId)}
          settings={settings}
          onClose={() => setSelectedSubmissionForReview(null)}
          onSaveReview={updated => {
            storage.updateSubmission(updated);
            onRefreshData();
          }}
          onOpenReceipt={sub => {
            setSelectedSubmissionForReview(null);
            setSelectedSubmissionForReceipt(sub);
          }}
        />
      )}

      {/* Receipt Modal */}
      {selectedSubmissionForReceipt && (
        <SubmissionReceiptModal
          submission={selectedSubmissionForReceipt}
          assignment={assignments.find(a => a.id === selectedSubmissionForReceipt.assignmentId)}
          course={courses.find(c => c.id === selectedSubmissionForReceipt.courseId)}
          settings={settings}
          onClose={() => setSelectedSubmissionForReceipt(null)}
        />
      )}
    </div>
  );
};
