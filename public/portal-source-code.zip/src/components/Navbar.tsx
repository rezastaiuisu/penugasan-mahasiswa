import React from 'react';
import { 
  GraduationCap, 
  Send, 
  SearchCheck, 
  LayoutDashboard, 
  BookOpen, 
  CalendarClock,
  Sparkles,
  Lock
} from 'lucide-react';
import { LecturerSettings } from '../types';

interface NavbarProps {
  activeTab: 'submit' | 'validate' | 'assignments' | 'admin';
  setActiveTab: (tab: 'submit' | 'validate' | 'assignments' | 'admin') => void;
  settings: LecturerSettings;
  submissionCount: number;
  isLoggedIn: boolean;
  onAdminClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  settings,
  submissionCount,
  isLoggedIn,
  onAdminClick,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Banner with University & Lecturer info */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-indigo-950 text-white text-xs px-4 py-1.5 font-medium">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold text-[11px] border border-emerald-500/30">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              PORTAL RESMI
            </span>
            <span className="text-slate-200">
              {settings.kampus} • Dosen Pengampu: <strong className="text-white">{settings.namaDosen}, {settings.gelar}</strong>
            </span>
          </div>
          <div className="flex items-center gap-4 text-slate-300 text-[11px]">
            <span className="hidden sm:inline-flex items-center gap-1">
              <CalendarClock className="w-3.5 h-3.5 text-teal-300" />
              Semester Ganjil 2026/2027
            </span>
            <span className="hidden md:inline-flex text-emerald-300">
              {settings.emailDosen}
            </span>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div 
            onClick={() => setActiveTab('submit')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-teal-700/20 group-hover:scale-105 transition-transform">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-900 tracking-tight text-lg">
                  Portal<span className="text-teal-600">Tugas</span>
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-teal-100 text-teal-800 uppercase tracking-wider">
                  STAI-UISU
                </span>
              </div>
              <p className="text-xs text-slate-500 -mt-0.5 hidden sm:block">
                Sistem Penugasan Mahasiswa Dosen Reza Lubis
              </p>
            </div>
          </div>

          {/* Nav Items */}
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('submit')}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'submit'
                  ? 'bg-teal-50 text-teal-700 shadow-xs border border-teal-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Send className="w-4 h-4 text-teal-600" />
              <span>Kirim Tugas</span>
            </button>

            <button
              onClick={() => setActiveTab('validate')}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'validate'
                  ? 'bg-indigo-50 text-indigo-700 shadow-xs border border-indigo-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <SearchCheck className="w-4 h-4 text-indigo-600" />
              <span>Cek Status NIM</span>
            </button>

            <button
              onClick={() => setActiveTab('assignments')}
              className={`hidden md:flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'assignments'
                  ? 'bg-slate-100 text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-4 h-4 text-slate-500" />
              <span>Daftar Tugas</span>
            </button>

            {/* Admin Dashboard Switch */}
            <div className="pl-2 border-l border-slate-200 ml-1">
              <button
                onClick={onAdminClick}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-bold transition-all cursor-pointer ${
                  activeTab === 'admin'
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-slate-900'
                }`}
                title={isLoggedIn ? 'Portal Dosen (Sedang Login)' : 'Klik untuk Login Dosen'}
              >
                {isLoggedIn ? (
                  <LayoutDashboard className="w-4 h-4 text-teal-400" />
                ) : (
                  <Lock className="w-3.5 h-3.5 text-slate-500" />
                )}
                <span className="hidden sm:inline">Portal Dosen</span>
                <span className="sm:hidden">Dosen</span>
                {submissionCount > 0 && (
                  <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-[11px] font-bold rounded-full bg-teal-500 text-white">
                    {submissionCount}
                  </span>
                )}
              </button>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};
